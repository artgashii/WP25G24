using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace EventManagementMvc.Areas.Admin.Views.Home
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
