using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace EventManagementMvc.Views.Events
{
    public class PermissionsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
